package poepart1;
import java.util.Scanner;

public class POEPART1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();
        System.out.println("=== REGISTER ===");
        System.out.print("Enter First Name: ");
       String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
        System.out.print("Enter Cell (+27...): ");
        String cell = scanner.nextLine();
        String result = login.registerUser(firstName, lastName, username, password, cell);
        System.out.println(result);
        if (result.contains("successfully")) {
            System.out.println("\n=== LOGIN ===");
            System.out.print("Enter Username: ");
            String inputUser = scanner.nextLine();
            System.out.print("Enter Password: ");
            String inputPass = scanner.nextLine();
            boolean isLoggedIn = login.loginUser(inputUser, inputPass);
            System.out.println(login.returnLoginStatus(isLoggedIn));
        }
        scanner.close();
    }
}